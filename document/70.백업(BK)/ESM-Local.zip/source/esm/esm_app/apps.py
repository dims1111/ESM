from django.apps import AppConfig


class EsmAppConfig(AppConfig):
    name = 'esm_app'
