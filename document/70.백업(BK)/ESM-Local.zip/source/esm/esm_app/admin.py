from django.contrib import admin
from . models import SysUser
from . models import SysUserAuth

# Register your models here.
class SysUserAdmin(admin.ModelAdmin):    
    list_display = ('user_id', 'user_account', 'user_name', 'hp_number', 'email_addr', 'person_id')


class SysUserAuthAdmin(admin.ModelAdmin):
    list_display = ('user_auth_id', 'user_id', 'auth_id', 'begin_date', 'end_date')

# 장고 Admin 등록
admin.site.register(SysUser, SysUserAdmin)
admin.site.register(SysUserAuth, SysUserAuthAdmin)
