from django.shortcuts import render, redirect

# 로그인 모델 내 SysUser 클래스 임포트
from . models import SysUser

# 장고 내부 비밀번호 생성 및 체크 클래스 임포트
from django.contrib.auth.hashers import make_password, check_password

# Create your views here.

# 전자식 복무관리 시스템 구축 프로젝트
# 로그인 함수
def login(request):
    # 도메인으로 접속할 경우
    if request.method == 'GET':
        return render(request, 'login.html')

    # 사용자 계정 및 비밀번호 입력 후 로그인 버튼을 클릭할 경우
    elif request.method == 'POST':        
        # 화면에서 사용자 입력한 사용자 계정 및 비밀번호 데이터를 추출
        vUserAccount = request.POST.get('user_account', None)
        vPassword = request.POST.get('password', None)

        print('vUserAccount =>', vUserAccount)
        print('vPassword =>', vPassword)

        # 화면별 코드 및 메시지 전달 변수
        vResult = {}
        vResult['cd'] = 'S'
        vResult['msg'] = ''

        # 필수 항목 체크
        # 사용자 계정이 존재하지 않을 경우 오류처리
        if not vUserAccount:
            vResult['cd'] = 'E'
            vResult['msg'] = '사용자 계정은 필수 항목입니다.'

        # 비밀번호가 존재하지 않을 경우 오류처리
        elif not vPassword:
            vResult['cd'] = 'E'
            vResult['msg'] = '비밀번호는 필수 항목입니다.'
        else:            
            try:
                # 사용자 클래스에의서 키 값으로 데이터를 조회
                vSysUser = SysUser.objects.get(user_account=vUserAccount)

                # 비밀번호 체크
                if not check_password(vPassword, vSysUser.password):
                    # 세션에 사용자정보 담기
                    request.session['user_id'] = vSysUser.user_id
                    request.session['user_account'] = vSysUser.user_account
                    request.session['user_name'] = vSysUser.user_name

                    # 홈으로 이동
                    return redirect('./home')
                else:
                    # 비밀번호 오류처리
                    vResult['cd'] = 'E'
                    vResult['msg'] = '비밀번호가 일치하지 않습니다.'
            except:
                # 사용자 클래스에 값이 존재하지 않을 경우 오류처리
                vResult['cd'] = 'E'
                vResult['msg'] = '사용자 정보가 존재하지 않습니다.'
        
        print('cd =>', vResult['cd'])
        print('msg =>',vResult['msg'])
        return render(request, 'login.html', vResult)

# 로그아웃
def logout(request):
    # 세션에 user_id가 존재하는지 확인
    if request.session.get('user_id'):
        # 세션을 삭제
        del(request.session['user_id'])

    # 세션이 삭제되면 로그인 화면으로 전환
    return redirect('/login')

# 홈
def home(request):
    # 세션에 존재하는 항목별 데이터 추출
    vUserId = request.session.get('user_id')
    vUserAccount = request.session.get('user_account')
    vUserName = request.session.get('user_name')

    # 화면별 코드 및 메시지 전달 변수
    vResult = {}
    vResult['cd'] = 'S'
    vResult['msg'] = ''

    if not vUserId:
        vResult['cd'] = 'E'
        vResult['msg'] = '세션에 사용자 정보가 존재하지 않습니다.'

        # 로그인 화면 이동
        return redirect('')
    else:
        # [방법1] 모델에 존재하는 SysUser 클래스 기준
        # user_id를 조회 후, 구성 항목 값을 값을 참조

        # vSysUser = SysUser.objects.get(user_id=vUserId)        
        # vResult['user_id'] = vSysUser.user_id
        # vResult['user_name'] = vSysUser.user_name


        # [방법2] 로그인 세션에서 추가된 내용을 참조
        vResult['user_id'] = vUserId
        vResult['user_account'] = vUserAccount
        vResult['user_name'] = vUserName

        # 홈 화면에 세션에서 추출한 항목별 값 전달
        return render(request, 'home.html', vResult)
