from django.urls import path

# 현재 앱에 작성 뷰 임포트
from . import views

urlpatterns = [
        path('', views.login),
        path('logout/', views.logout),
        path('home/', views.home),       
]