from django.apps import AppConfig


class StaticTemplateConfig(AppConfig):
    name = 'static_template'
