from django.contrib import admin

# 메뉴 모델의 SysMenu 클래스 임포트
from . models import SysMenu

# 장고 Admin 테이블 조회 시 조회될 컬럼 정의
class SysMenuAdmin(admin.ModelAdmin):    
    list_display = ('menu_id',
                   'menu_name_ko',
                   'menu_name_en',
                   'url',
                   'prent_menu_id',
                   'icons',
                   'sort_order',
                   'user_yn',
                   'user_insert_yn',
                   'user_update_yn',
                   'user_delete_yn',
                   'user_print_yn',
                   'user_batch_yn',
                   'user_excel_down_yn',
                   'user_excel_up_yn')

# 장고 Admin 등록
admin.site.register(SysMenu, SysMenuAdmin)