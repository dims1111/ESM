from django.shortcuts import render

# 로그인 메뉴 내 SysUser 클래스 임포트
from . models import SysMenu


# 메인 함수
def main(request):
    return render(request, 'esm_sys_1010M.html')

# 조회 함수
def search(request):
    pass

# 저장 함수
def insert(request):
    pass

# 수정 함수
def update(request):
    pass

# 삭제 함수
def delete(request):
    pass

