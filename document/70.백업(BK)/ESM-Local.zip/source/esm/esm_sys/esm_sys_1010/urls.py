from django.urls import path

# 메뉴 앱에 작성 뷰 임포트
from . import views

urlpatterns = [
        path('', views.main),
        path('search/', views.search),
        path('insert/', views.insert),
        path('update/', views.update),
        path('delete/', views.delete),
]