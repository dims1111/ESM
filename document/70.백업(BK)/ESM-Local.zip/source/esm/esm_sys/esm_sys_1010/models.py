from django.db import models

# 메뉴 클래스
class SysMenu(models.Model):
    menu_id = models.IntegerField(primary_key=True, verbose_name="메뉴ID")
    menu_name_ko = models.CharField(max_length=100, verbose_name="메뉴명(한글)")
    menu_name_en = models.CharField(max_length=200, verbose_name="메뉴명(영문)")
    url = models.CharField(max_length=200, blank=True, null=True, verbose_name="URL")
    prent_menu_id = models.IntegerField(verbose_name="상위메뉴ID")
    icons = models.CharField(max_length=1000, blank=True, null=True, verbose_name="아이콘")
    sort_order = models.IntegerField(blank=True, null=True, default=1000, verbose_name="정렬순서")
    user_yn = models.CharField(max_length=1, default="Y", verbose_name="사용여부")
    user_insert_yn = models.CharField(max_length=1, default="Y", verbose_name="신규여부")
    user_update_yn = models.CharField(max_length=1, default="Y", verbose_name="수정여부")
    user_delete_yn = models.CharField(max_length=1, default="Y", verbose_name="삭제여부")
    user_print_yn = models.CharField(max_length=1, default="N", verbose_name="출력여부")
    user_batch_yn = models.CharField(max_length=1, default="N", verbose_name="생성여부")
    user_excel_down_yn = models.CharField(max_length=1, default="Y", verbose_name="엑셀다운로드여부")
    user_excel_up_yn = models.CharField(max_length=1, default="N", verbose_name="엑셀업로드여부")
    remark = models.CharField(max_length=2000, blank=True, null=True, verbose_name="비고")
    create_date_time = models.DateTimeField(blank=True, null=True, auto_now_add=True, verbose_name="생성일시")
    create_by = models.IntegerField(blank=True, null=True, default=-1, verbose_name="생성자ID")
    update_date_time = models.DateTimeField(blank=True, null=True, auto_now_add=True, verbose_name="수정일시")
    update_by = models.IntegerField(blank=True, null=True, default=-1, verbose_name="수정자ID")

    class Meta:
        managed = False
        db_table = 'sys_menu'
        verbose_name = '메뉴'
        verbose_name_plural = '메뉴'
        ordering = ['sort_order']