from django.apps import AppConfig


class EsmSys1010Config(AppConfig):
    name = 'esm_sys_1010'
